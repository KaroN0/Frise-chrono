
import { GoogleGenAI } from "@google/genai";

export const generateEventDescription = async (apiKey: string, year: string, title: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey });
  const prompt = `Génère une description concise et éducative pour l'événement historique suivant : "${title}" en l'an ${year}. Le texte doit être en français, captivant et faire environ 100-150 mots.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      temperature: 0.7,
      maxOutputTokens: 500,
    }
  });

  return response.text || "Erreur lors de la génération de la description.";
};

export const generateEventImage = async (apiKey: string, prompt: string): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: `A highly detailed, historical style illustration of: ${prompt}. Cinematic lighting, evocative atmosphere.` }]
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};
