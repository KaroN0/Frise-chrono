import React from 'react';
import { Edit3, Trash2, Info } from 'lucide-react';
import { TimelineEvent } from '../types';

interface EventBlockProps {
  event: TimelineEvent;
  align: 'left' | 'right' | 'center';
  lineColor: string;
  onViewDetails: (e: TimelineEvent) => void;
  onEdit: (e: TimelineEvent) => void;
  onDelete: (id: string) => void;
}

const EventBlock: React.FC<EventBlockProps> = ({ event, align, lineColor, onViewDetails, onEdit, onDelete }) => {
  const alignmentClass = align === 'right' ? 'items-end' : align === 'left' ? 'items-start' : 'items-center';
  const textAlignClass = align === 'right' ? 'text-right' : align === 'left' ? 'text-left' : 'text-center';

  return (
    <div className={`flex flex-col ${alignmentClass} group relative animate-fade-in w-full max-w-[280px]`}>
      {/* Date */}
      <div className="mb-1">
        <span 
          className="text-3xl font-black font-historical tracking-tighter"
          style={{ color: lineColor }}
        >
          {event.year}
        </span>
      </div>

      {/* Titre */}
      <div className={`mb-4 min-h-[2.5rem] flex items-center ${textAlignClass}`}>
        <h3 className="text-lg font-bold text-stone-800 leading-tight font-serif-elegant">
          {event.title}
        </h3>
      </div>

      {/* Image (Format Carré - Square) */}
      <div className="relative w-48 h-48 rounded-xl border-4 border-white overflow-hidden shadow-lg bg-stone-100 mb-4 group-hover:shadow-2xl transition-all duration-300 transform group-hover:scale-[1.03]">
        <img 
          src={event.imageUrl || 'https://images.unsplash.com/photo-1585642953348-133529321893?q=80&w=400&auto=format&fit=crop'} 
          alt={event.title}
          className="w-full h-full object-cover"
        />
        
        {/* Actions au survol */}
        <div className="absolute inset-0 bg-stone-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-3">
          <button 
            onClick={() => onEdit(event)}
            className="p-2 bg-white/20 hover:bg-white/40 backdrop-blur-md rounded-full text-white transition-colors border border-white/30"
          >
            <Edit3 className="w-5 h-5" />
          </button>
          <button 
            onClick={() => onDelete(event.id)}
            className="p-2 bg-red-500/80 hover:bg-red-600 rounded-full text-white transition-colors border border-white/30"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Bouton En savoir + */}
      <button 
        onClick={() => onViewDetails(event)}
        className="flex items-center gap-2 px-4 py-2 bg-stone-800 text-white rounded-full text-[11px] font-black uppercase tracking-widest hover:bg-orange-600 transition-all shadow-md active:scale-95"
      >
        <Info className="w-3.5 h-3.5" />
        En savoir +
      </button>

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.4s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default EventBlock;