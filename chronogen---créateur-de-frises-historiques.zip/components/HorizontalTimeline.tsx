import React from 'react';
import { TimelineEvent } from '../types';
import EventBlock from './EventBlock';

interface HorizontalTimelineProps {
  events: TimelineEvent[];
  lineColor: string;
  onViewDetails: (e: TimelineEvent) => void;
  onEdit: (e: TimelineEvent) => void;
  onDelete: (id: string) => void;
}

const HorizontalTimeline: React.FC<HorizontalTimelineProps> = ({ 
  events, 
  lineColor, 
  onViewDetails, 
  onEdit, 
  onDelete 
}) => {
  return (
    <div className="min-w-max relative py-48 px-20 no-scrollbar overflow-x-auto flex items-center min-h-[1000px]">
      {/* Ligne Centrale Horizontale */}
      <div 
        className="absolute left-0 right-0 h-1.5 top-1/2 -translate-y-1/2 shadow-sm opacity-60"
        style={{ backgroundColor: lineColor }}
      />

      <div className="flex gap-40">
        {events.map((event, index) => {
          const isTop = index % 2 === 0;
          return (
            <div key={event.id} className="relative flex flex-col items-center">
              {/* Alternance Haut / Bas avec espacement suffisant pour le format carré */}
              <div className={`absolute ${isTop ? 'bottom-[calc(50%+40px)]' : 'top-[calc(50%+40px)]'} w-[220px]`}>
                <EventBlock 
                  event={event} 
                  align="center"
                  onViewDetails={onViewDetails}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  lineColor={lineColor}
                />
              </div>

              {/* Point de connexion sur la ligne */}
              <div 
                className="w-5 h-5 rounded-full border-4 border-white shadow-lg z-10 transition-transform hover:scale-125 cursor-pointer"
                style={{ backgroundColor: lineColor }}
              />
              
              {/* Petit trait vertical de liaison */}
              <div 
                className={`absolute w-0.5 h-10 opacity-20 ${isTop ? 'bottom-[calc(50%+5px)]' : 'top-[calc(50%+5px)]'}`}
                style={{ backgroundColor: lineColor }}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HorizontalTimeline;