
import React, { useState } from 'react';
import { Key, ExternalLink, Check, AlertCircle, ShieldCheck } from 'lucide-react';

interface ApiKeyPromptProps {
  onKeySaved: (key: string) => void;
}

const ApiKeyPrompt: React.FC<ApiKeyPromptProps> = ({ onKeySaved }) => {
  const [key, setKey] = useState('');

  const handleSave = () => {
    const trimmedKey = key.trim();
    if (trimmedKey.length < 20) return;
    localStorage.setItem('CHRONOGEN_GEMINI_KEY', trimmedKey);
    onKeySaved(trimmedKey);
  };

  return (
    <div className="bg-orange-600 rounded-2xl p-5 mb-6 shadow-xl shadow-orange-100 animate-slide-down border-2 border-orange-400">
      <div className="flex items-start gap-4">
        <div className="p-3 bg-white/20 backdrop-blur-md rounded-xl text-white">
          <Key className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <h4 className="text-base font-bold text-white mb-1 flex items-center gap-2">
            Configuration de l'IA
            <ShieldCheck className="w-4 h-4 text-orange-200" />
          </h4>
          <p className="text-xs text-orange-50 mb-4 leading-relaxed font-medium">
            Pour générer des contenus, vous devez entrer votre clé Google Gemini. 
            Elle est <strong>gratuite</strong> et reste stockée en toute sécurité sur votre navigateur.
          </p>
          
          <div className="flex gap-2">
            <input 
              type="password"
              placeholder="Collez votre clé API (AIza...)"
              className="flex-1 px-4 py-2 bg-white border-0 rounded-xl text-sm outline-none focus:ring-4 focus:ring-orange-300 text-gray-900 placeholder:text-stone-400"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              autoFocus
            />
            <button 
              onClick={handleSave}
              disabled={key.trim().length < 20}
              className="px-5 py-2 bg-white text-orange-700 rounded-xl text-sm font-black hover:bg-orange-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 flex items-center gap-2 shadow-lg"
            >
              <Check className="w-4 h-4" />
              Activer
            </button>
          </div>
          
          <div className="flex items-center justify-between mt-4">
            <a 
              href="https://aistudio.google.com/app/apikey" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[10px] font-black text-white hover:text-orange-200 uppercase tracking-widest transition-colors"
            >
              Obtenir une clé gratuitement
              <ExternalLink className="w-3 h-3" />
            </a>
            <span className="text-[10px] text-orange-200 font-bold uppercase tracking-tight">Sécurisé par Google AI</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyPrompt;
