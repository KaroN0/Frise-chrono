
import React, { useState, useRef, useEffect } from 'react';
import { X, Image as ImageIcon, Sparkles, Upload, Link as LinkIcon, Save } from 'lucide-react';
import { TimelineEvent } from '../types';
import { generateEventImage } from '../services/geminiService';
import ApiKeyPrompt from './ApiKeyPrompt';

interface EventModalProps {
  event: TimelineEvent | null;
  onClose: () => void;
  onSave: (event: TimelineEvent) => void;
}

const EventModal: React.FC<EventModalProps> = ({ event, onClose, onSave }) => {
  const [formData, setFormData] = useState<TimelineEvent>({
    id: event?.id || Date.now().toString(),
    year: event?.year || '',
    title: event?.title || '',
    imageUrl: event?.imageUrl || '',
    description: event?.description || ''
  });

  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [showKeyPrompt, setShowKeyPrompt] = useState(false);
  const [apiKey, setApiKey] = useState<string | null>(localStorage.getItem('CHRONOGEN_GEMINI_KEY'));
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Synchroniser la clé si elle est modifiée dans la sidebar
  useEffect(() => {
    const handleStorage = () => {
      setApiKey(localStorage.getItem('CHRONOGEN_GEMINI_KEY'));
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, imageUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateImage = async () => {
    if (!formData.title) {
      alert("Veuillez d'abord saisir un titre pour l'image.");
      return;
    }

    if (!apiKey || apiKey.trim().length < 20) {
      setShowKeyPrompt(true);
      return;
    }

    setIsGeneratingImage(true);
    try {
      const url = await generateEventImage(apiKey, formData.title);
      if (url) setFormData({ ...formData, imageUrl: url });
    } catch (error: any) {
      console.error(error);
      if (error.message?.includes('API_KEY_INVALID') || error.message?.includes('403')) {
        alert("Clé API invalide ou expirée.");
        localStorage.removeItem('CHRONOGEN_GEMINI_KEY');
        setApiKey(null);
        setShowKeyPrompt(true);
      } else {
        alert("Erreur lors de la génération de l'image.");
      }
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.year || !formData.title) {
      alert("L'année et le titre sont requis.");
      return;
    }
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative bg-white w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-zoom-in">
        <div className="px-6 py-4 border-b flex items-center justify-between bg-stone-50">
          <h2 className="text-xl font-bold text-stone-800">
            {event ? 'Modifier l\'événement' : 'Nouvel événement'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-stone-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-stone-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto custom-scrollbar">
          {showKeyPrompt && (!apiKey || apiKey.trim().length < 20) && (
            <ApiKeyPrompt onKeySaved={(key) => { setApiKey(key); setShowKeyPrompt(false); }} />
          )}

          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-1">
              <label className="block text-sm font-semibold text-stone-700 mb-1">Année</label>
              <input 
                type="text"
                placeholder="Ex: 1789"
                className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                value={formData.year}
                onChange={e => setFormData({ ...formData, year: e.target.value })}
                required
              />
            </div>
            <div className="col-span-3">
              <label className="block text-sm font-semibold text-stone-700 mb-1">Titre de l'événement</label>
              <input 
                type="text"
                placeholder="Ex: Prise de la Bastille"
                className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-2">Illustration</label>
            <div className="flex gap-4 items-start">
              <div className="w-32 h-32 bg-stone-100 rounded-xl border-2 border-dashed border-stone-300 flex-shrink-0 flex items-center justify-center overflow-hidden shadow-inner">
                {formData.imageUrl ? (
                  <img src={formData.imageUrl} className="w-full h-full object-cover" alt="Prévisualisation" />
                ) : (
                  <ImageIcon className="w-8 h-8 text-stone-300" />
                )}
              </div>
              <div className="flex-1 space-y-2">
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Lien URL de l'image..."
                    className="w-full pl-9 pr-3 py-1.5 border border-stone-200 rounded-lg text-sm focus:ring-2 focus:ring-orange-500 outline-none"
                    value={formData.imageUrl.startsWith('data:') ? '' : formData.imageUrl}
                    onChange={e => setFormData({ ...formData, imageUrl: e.target.value })}
                  />
                  <LinkIcon className="absolute left-3 top-2 w-4 h-4 text-stone-400" />
                </div>
                
                <div className="flex gap-2">
                  <button 
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 rounded-lg text-xs font-semibold text-stone-700 transition-colors border border-stone-200"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Importer
                  </button>
                  <button 
                    type="button"
                    onClick={handleGenerateImage}
                    disabled={isGeneratingImage}
                    className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-orange-50 hover:bg-orange-100 rounded-lg text-xs font-semibold text-orange-700 transition-all border border-orange-100 shadow-sm"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    {isGeneratingImage ? 'Génération...' : 'Créer par IA'}
                  </button>
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*"
                  onChange={handleFileChange}
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-1">Brève description (Facultatif)</label>
            <textarea 
              rows={3}
              placeholder="Une courte introduction..."
              className="w-full px-3 py-2 border border-stone-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none resize-none"
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="flex gap-3 pt-4 border-t mt-4">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-stone-300 rounded-lg font-semibold text-stone-700 hover:bg-stone-50 transition-colors"
            >
              Annuler
            </button>
            <button 
              type="submit"
              className="flex-1 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 shadow-lg shadow-orange-100 transition-all active:scale-[0.98]"
            >
              <Save className="w-5 h-5" />
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EventModal;
