
import React from 'react';
import { TimelineEvent } from '../types';
import EventBlock from './EventBlock';

interface VerticalTimelineProps {
  events: TimelineEvent[];
  lineColor: string;
  onViewDetails: (e: TimelineEvent) => void;
  onEdit: (e: TimelineEvent) => void;
  onDelete: (id: string) => void;
}

const VerticalTimeline: React.FC<VerticalTimelineProps> = ({ 
  events, 
  lineColor, 
  onViewDetails, 
  onEdit, 
  onDelete 
}) => {
  return (
    <div className="max-w-4xl mx-auto relative py-10">
      {/* Central Line */}
      <div 
        className="absolute left-1/2 top-0 bottom-0 w-1 -translate-x-1/2 opacity-30 sm:opacity-100"
        style={{ backgroundColor: lineColor }}
      />

      <div className="space-y-12 sm:space-y-24">
        {events.map((event, index) => {
          const isEven = index % 2 === 0;
          return (
            <div key={event.id} className={`flex items-center w-full ${isEven ? 'justify-start' : 'justify-end'}`}>
              <div className={`w-full sm:w-[45%] ${isEven ? 'text-right' : 'text-left'}`}>
                <EventBlock 
                  event={event} 
                  align={isEven ? 'right' : 'left'}
                  onViewDetails={onViewDetails}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  lineColor={lineColor}
                />
              </div>
              
              {/* Node on the line */}
              <div 
                className="absolute left-1/2 -translate-x-1/2 w-4 h-4 rounded-full border-4 border-white shadow-md z-10"
                style={{ backgroundColor: lineColor }}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default VerticalTimeline;
