
import React, { useRef, useState, useEffect } from 'react';
import { 
  X, Palette, Image as ImageIcon, Share2, 
  FileImage, FileText, Camera, Upload, 
  Key, ShieldCheck, Check, ExternalLink,
  Type, ChevronDown, ChevronUp
} from 'lucide-react';
import { AppSettings } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSettingsChange: (s: AppSettings) => void;
  onExport: (format: 'png' | 'pdf' | 'jpeg') => void;
  onShare: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, settings, onSettingsChange, onExport, onShare }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [apiKey, setApiKey] = useState(localStorage.getItem('CHRONOGEN_GEMINI_KEY') || '');
  const [isAiFolderOpen, setIsAiFolderOpen] = useState(false);

  const handleBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onSettingsChange({ ...settings, bgImageUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const saveApiKey = () => {
    localStorage.setItem('CHRONOGEN_GEMINI_KEY', apiKey.trim());
    setIsAiFolderOpen(false);
    window.dispatchEvent(new Event('storage'));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div 
        className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />
      
      <aside className="relative w-[340px] bg-white h-full shadow-2xl flex flex-col animate-slide-in-left border-r border-stone-200">
        <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <h2 className="text-xl font-bold flex items-center gap-2 text-stone-800">
            <Palette className="w-5 h-5 text-orange-600" />
            Personnalisation
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-stone-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-stone-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-8 no-scrollbar">
          {/* Section Titre */}
          <section>
            <label className="block text-[10px] font-black text-stone-400 mb-3 uppercase tracking-[0.2em] flex items-center gap-2">
              <Type className="w-3.5 h-3.5 text-amber-600" />
              Titre de la frise
            </label>
            <input 
              type="text"
              placeholder="Ex: L'histoire de France"
              className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl text-sm font-bold text-stone-800 outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all"
              value={settings.title}
              onChange={(e) => onSettingsChange({ ...settings, title: e.target.value })}
            />
          </section>

          {/* Couleurs */}
          <section>
            <label className="block text-[10px] font-black text-stone-400 mb-3 uppercase tracking-[0.2em] flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full" />
              Palette de couleurs
            </label>
            <div className="space-y-4">
              <div>
                <p className="text-[10px] font-bold text-stone-400 mb-2 uppercase">Fond de page</p>
                <div className="grid grid-cols-5 gap-2">
                  {['#fdfbf7', '#fefce8', '#fffbeb', '#fcfcfc', '#f5f5f5', '#ffffff', '#e5e7eb', '#1f2937', '#000000'].map(color => (
                    <button
                      key={color}
                      onClick={() => onSettingsChange({ ...settings, bgColor: color })}
                      className={`w-full aspect-square rounded-lg border-2 transition-all hover:scale-110 shadow-sm ${settings.bgColor === color ? 'border-orange-600 ring-2 ring-orange-100 scale-105' : 'border-transparent'}`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
              
              <div>
                <p className="text-[10px] font-bold text-stone-400 mb-2 uppercase">Ligne chronologique</p>
                <div className="flex gap-2">
                  {['#c2410c', '#b45309', '#f59e0b', '#ef4444', '#000000', '#6b7280'].map(color => (
                    <button
                      key={color}
                      onClick={() => onSettingsChange({ ...settings, lineColor: color })}
                      className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-110 shadow-sm ${settings.lineColor === color ? 'border-stone-900 ring-2 ring-stone-100' : 'border-transparent'}`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Image de fond */}
          <section className="bg-stone-50 -mx-5 px-5 py-6 border-y border-stone-100">
            <label className="block text-[10px] font-black text-stone-400 mb-3 uppercase tracking-[0.2em] flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-amber-500 rounded-full" />
              Image de fond
            </label>
            
            <div className="space-y-4">
              <div 
                className={`relative group h-40 w-full rounded-2xl border-2 border-dashed transition-all flex flex-col items-center justify-center overflow-hidden bg-white shadow-inner
                ${settings.bgImageUrl ? 'border-orange-200' : 'border-stone-200 hover:border-orange-300'}`}
              >
                {settings.bgImageUrl ? (
                  <>
                    <img src={settings.bgImageUrl} className="w-full h-full object-cover" alt="Fond sélectionné" />
                    <div className="absolute inset-0 bg-stone-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2 bg-white/20 hover:bg-white/40 backdrop-blur-md rounded-lg text-white font-bold text-xs"
                      >
                        Changer
                      </button>
                      <button 
                        onClick={() => onSettingsChange({ ...settings, bgImageUrl: '' })}
                        className="p-2 bg-red-500/80 hover:bg-red-600 rounded-lg text-white font-bold text-xs"
                      >
                        Supprimer
                      </button>
                    </div>
                  </>
                ) : (
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex flex-col items-center gap-2 text-stone-400 hover:text-orange-500 transition-colors"
                  >
                    <Upload className="w-8 h-8" />
                    <span className="text-xs font-bold uppercase tracking-tighter">Télécharger une image</span>
                  </button>
                )}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*"
                  onChange={handleBgUpload}
                />
              </div>

              <div className="relative">
                <p className="text-[10px] font-bold text-stone-400 mb-2 uppercase">Ou via une URL directe</p>
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="https://..."
                    className="w-full pl-9 pr-4 py-2 bg-white border border-stone-200 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none text-xs shadow-sm"
                    value={settings.bgImageUrl.startsWith('data:') ? '' : settings.bgImageUrl}
                    onChange={(e) => onSettingsChange({ ...settings, bgImageUrl: e.target.value })}
                  />
                  <ImageIcon className="absolute left-3 top-2 w-4 h-4 text-stone-400" />
                </div>
              </div>
            </div>
          </section>

          {/* Export & Partage */}
          <section className="space-y-3 pb-8 border-b border-stone-100">
            <label className="block text-[10px] font-black text-stone-400 mb-3 uppercase tracking-[0.2em] flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-amber-600 rounded-full" />
              Sortie & Diffusion
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => onExport('png')}
                className="flex flex-col items-center gap-2 p-3 bg-white border border-stone-100 rounded-2xl hover:bg-orange-50 hover:border-orange-200 transition-all shadow-sm group"
              >
                <FileImage className="w-6 h-6 text-orange-500 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black uppercase text-stone-500">Image PNG</span>
              </button>
              <button 
                onClick={() => onExport('jpeg')}
                className="flex flex-col items-center gap-2 p-3 bg-white border border-stone-100 rounded-2xl hover:bg-amber-50 hover:border-amber-200 transition-all shadow-sm group"
              >
                <Camera className="w-6 h-6 text-amber-500 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black uppercase text-stone-500">Image JPG</span>
              </button>
            </div>
            <button 
              onClick={() => onExport('pdf')}
              className="w-full flex items-center gap-3 px-4 py-3 bg-white border border-stone-100 rounded-2xl hover:bg-stone-50 hover:border-stone-200 transition-all shadow-sm group"
            >
              <div className="w-10 h-10 bg-stone-50 rounded-xl flex items-center justify-center group-hover:bg-stone-100 transition-colors">
                <FileText className="w-6 h-6 text-stone-500" />
              </div>
              <div className="text-left">
                <p className="text-xs font-black text-stone-800 uppercase tracking-tight">Document PDF</p>
                <p className="text-[10px] text-stone-400 uppercase font-bold">Prêt pour l'impression</p>
              </div>
            </button>
            <button 
              onClick={onShare}
              className="w-full flex items-center gap-3 px-4 py-4 bg-orange-600 text-white rounded-2xl hover:bg-orange-700 transition-all font-black shadow-xl shadow-orange-100 active:scale-95"
            >
              <Share2 className="w-5 h-5" />
              <span className="text-sm uppercase tracking-wider">Partager le lien</span>
            </button>
          </section>

          {/* Section API KEY DISCRETE */}
          <section className="pt-2">
             <button 
              onClick={() => setIsAiFolderOpen(!isAiFolderOpen)}
              className="w-full flex items-center justify-between text-[10px] font-black text-stone-400 uppercase tracking-widest hover:text-orange-600 transition-colors px-2 py-2 rounded-lg hover:bg-stone-50"
            >
              <span className="flex items-center gap-2">
                <Key className="w-3.5 h-3.5" />
                Configuration Avancée IA
              </span>
              {isAiFolderOpen ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            
            {isAiFolderOpen && (
              <div className="mt-4 p-4 bg-stone-50 border border-stone-200 rounded-2xl space-y-3 animate-slide-down">
                <p className="text-[10px] text-stone-500 leading-relaxed italic">
                  La clé API est requise pour la génération automatique d'images et de textes. Elle est stockée localement dans votre navigateur.
                </p>
                <div className="relative">
                  <input 
                    type="password"
                    placeholder="Clé API Gemini (AIza...)"
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-lg text-xs outline-none focus:ring-2 focus:ring-orange-500"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                </div>
                <button 
                  onClick={saveApiKey}
                  className="w-full py-2 bg-stone-800 text-white rounded-lg text-[10px] font-black uppercase flex items-center justify-center gap-2 hover:bg-stone-900 transition-colors"
                >
                  <Check className="w-3 h-3" />
                  Mettre à jour la clé
                </button>
                <a 
                  href="https://aistudio.google.com/app/apikey" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-1 text-[9px] font-bold text-orange-500 uppercase tracking-tighter hover:text-orange-700"
                >
                  Obtenir une clé gratuite <ExternalLink className="w-2 h-2" />
                </a>
              </div>
            )}
          </section>
        </div>
      </aside>

      <style>{`
        @keyframes slide-in-left {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }
        .animate-slide-in-left {
          animation: slide-in-left 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default Sidebar;
