
import React, { useState } from 'react';
import { X, Sparkles, Edit3, Save, History } from 'lucide-react';
import { TimelineEvent } from '../types';
import { generateEventDescription } from '../services/geminiService';
import ApiKeyPrompt from './ApiKeyPrompt';

interface DescriptionModalProps {
  event: TimelineEvent;
  onClose: () => void;
  onUpdate: (event: TimelineEvent) => void;
}

const DescriptionModal: React.FC<DescriptionModalProps> = ({ event, onClose, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [description, setDescription] = useState(event.description);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showKeyPrompt, setShowKeyPrompt] = useState(false);
  const [apiKey, setApiKey] = useState<string | null>(localStorage.getItem('CHRONOGEN_GEMINI_KEY'));

  const handleGenerate = async () => {
    if (!apiKey) {
      setShowKeyPrompt(true);
      return;
    }

    setIsGenerating(true);
    try {
      const text = await generateEventDescription(apiKey, event.year, event.title);
      setDescription(text);
      setIsEditing(true);
    } catch (error: any) {
      if (error.message?.includes('API_KEY_INVALID')) {
        alert("Clé API invalide. Veuillez la vérifier.");
        localStorage.removeItem('CHRONOGEN_GEMINI_KEY');
        setApiKey(null);
        setShowKeyPrompt(true);
      } else {
        alert("Erreur lors de la génération du texte.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    onUpdate({ ...event, description });
    setIsEditing(false);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-stone-900/70 backdrop-blur-md" onClick={onClose} />
      
      <div className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-zoom-in">
        <div className="h-48 relative">
          <img 
            src={event.imageUrl || 'https://images.unsplash.com/photo-1461360228754-6e81c478c882?q=80&w=2074&auto=format&fit=crop'} 
            className="w-full h-full object-cover" 
            alt={event.title}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-white via-white/40 to-transparent" />
          <button 
            onClick={onClose} 
            className="absolute top-4 right-4 p-2 bg-black/20 hover:bg-black/40 backdrop-blur-md rounded-full text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          
          <div className="absolute bottom-4 left-6 right-6">
            <span className="text-sm font-bold text-orange-700 uppercase tracking-widest bg-white/80 px-2 py-0.5 rounded backdrop-blur-sm">
              L'an {event.year}
            </span>
            <h2 className="text-3xl font-black text-stone-900 font-historical mt-1 drop-shadow-sm">
              {event.title}
            </h2>
          </div>
        </div>

        <div className="p-8">
          {showKeyPrompt && !apiKey && (
            <ApiKeyPrompt onKeySaved={(key) => { setApiKey(key); setShowKeyPrompt(false); }} />
          )}

          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-stone-800 flex items-center gap-2">
              <History className="w-5 h-5 text-orange-500" />
              À propos de cet événement
            </h3>
            
            <div className="flex gap-2">
              {!isEditing ? (
                <>
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="p-2 hover:bg-stone-100 rounded-lg text-stone-600 transition-colors"
                    title="Éditer manuellement"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="flex items-center gap-2 px-3 py-1.5 bg-orange-50 text-orange-700 rounded-lg hover:bg-orange-100 transition-colors font-semibold text-sm disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4" />
                    {isGenerating ? 'Génération...' : 'IA Générer'}
                  </button>
                </>
              ) : (
                <button 
                  onClick={handleSave}
                  className="flex items-center gap-2 px-4 py-1.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-semibold text-sm"
                >
                  <Save className="w-4 h-4" />
                  Enregistrer
                </button>
              )}
            </div>
          </div>

          <div className="prose prose-stone max-w-none">
            {isEditing ? (
              <textarea 
                className="w-full h-48 p-4 border-2 border-orange-100 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none font-serif-elegant leading-relaxed text-stone-700"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Rédigez ou générez l'histoire de cet événement..."
              />
            ) : (
              <p className="text-stone-700 leading-relaxed font-serif-elegant text-lg italic bg-stone-50/50 p-4 rounded-xl border border-stone-100">
                {description || "Aucune description disponible. Utilisez l'IA ou éditez ce champ pour en ajouter une."}
              </p>
            )}
          </div>
        </div>

        <div className="px-8 py-4 bg-stone-50 border-t flex justify-center">
          <p className="text-xs text-stone-400">© ChronoGen - Gardien de l'Histoire</p>
        </div>
      </div>
    </div>
  );
};

export default DescriptionModal;
